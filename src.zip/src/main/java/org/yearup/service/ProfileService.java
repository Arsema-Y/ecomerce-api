package org.yearup.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.yearup.models.Profile;
import org.yearup.repository.ProfileRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProfileService
{
    private final ProfileRepository profileRepository;

    public ProfileService(ProfileRepository profileRepository)
    {
        this.profileRepository = profileRepository;
    }

    public List<Profile> getProfile(){
        return profileRepository.findAll();
    }

    public Profile getById(int userId){
        return profileRepository.findById(userId)
                .orElseThrow (()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "User Not Found"));

    }

    public Profile create(Profile profile)
    {
        return profileRepository.save(profile);
    }

    public Profile update(int userId, Profile profile){
        Profile existing = profileRepository.findById(userId).orElseThrow();
        existing.setAddress(profile.getAddress());
        existing.setCity(profile.getCity());
        existing.setEmail(profile.getEmail());
        existing.setPhone(profile.getPhone());
        existing.setState(profile.getState());
        existing.setZip(profile.getZip());
        existing.setFirstName(profile.getFirstName());
        existing.setLastName(profile.getLastName());

        return profileRepository.save(existing);
    }

    public void delete(int userId)
    {
        profileRepository.deleteById(userId);
    }
}
