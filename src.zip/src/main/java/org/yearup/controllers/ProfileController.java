package org.yearup.controllers;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.yearup.models.Profile;
import org.yearup.service.ProfileService;

import java.util.List;

@RestController
@RequestMapping("profile")
public class ProfileController {

    private final ProfileService profileService;

    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @GetMapping
    public List<Profile> getProfile(){
        return profileService.getProfile();
    }

    @PostMapping
    public Profile createProfile(@RequestBody Profile profile){
        return profileService.create(profile);
    }

    @PutMapping("/{userId}")
    public Profile updateProfile(@PathVariable int userId, @RequestBody Profile profile){

        if (profileService.getById(userId) == null)
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);

        return profileService.update(userId, profile);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProfile(@PathVariable int userId)
    {
        if (profileService.getById(userId) == null)
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);

        profileService.delete(userId);
        return ResponseEntity.noContent().build();
    }

}
